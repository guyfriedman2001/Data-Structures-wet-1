#pragma once
#include "ProjectFiles.h"

class HorseNode : public AVLNode<Horse> {

};