#pragma once
#include "ProjectFiles.h"

class HorseNode : public AVLNode<Horse> {
public:
    ~HorseNode() override {
        this->value = nullptr;
        delete this->left;
        delete this->right;
    }

    HorseNode(Horse* horse, int id) : AVLNode(horse,id){}




};